from django.contrib import admin
from .models import PaitentDetails,AppointmentDetials

admin.site.register(PaitentDetails)
admin.site.register(AppointmentDetials)

# Register your models here.
