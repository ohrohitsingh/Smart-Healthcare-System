from django.apps import AppConfig


class DiseaseConfig(AppConfig):
    name = 'disease'
