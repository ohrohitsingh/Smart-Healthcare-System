from django.apps import AppConfig


class RmpWorkHistoryConfig(AppConfig):
    name = 'rmp_work_history'
