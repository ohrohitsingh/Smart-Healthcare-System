from django.apps import AppConfig


class ShowAppointmentsConfig(AppConfig):
    name = 'show_appointments'
