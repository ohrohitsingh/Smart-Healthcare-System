from django.apps import AppConfig


class doctor_profileConfig(AppConfig):
    name = 'doctor_profile'
