from django.contrib import admin
from .models import Post,Rmplist,ContactForm,NewsLetter

admin.site.register(Post)
admin.site.register(Rmplist)
admin.site.register(ContactForm)
admin.site.register(NewsLetter)