from django.apps import AppConfig


class ShoppingportalappConfig(AppConfig):
    name = 'shoppingPortalApp'
