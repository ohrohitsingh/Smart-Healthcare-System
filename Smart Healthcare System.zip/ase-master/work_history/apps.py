from django.apps import AppConfig


class WorkHistoryConfig(AppConfig):
    name = 'work_history'
