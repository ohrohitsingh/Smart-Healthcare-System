This is a project based on rural healthcare system. 
