from django.apps import AppConfig


class RmpConfig(AppConfig):
    name = 'rmp'
