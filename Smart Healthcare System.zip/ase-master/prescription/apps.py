from django.apps import AppConfig


class PrescriptionConfig(AppConfig):
    name = 'prescription'
