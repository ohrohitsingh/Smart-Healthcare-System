from django.contrib import admin
from .models import Profile1

admin.site.register(Profile1)